import { useState, useRef, useEffect, useCallback } from "react";
import { ImageWithFallback } from "@/app/components/figma/ImageWithFallback";
import craneImage from "@/imports/_______.png";
import virgaLogo from "@/imports/virgalogo.png";
import {
  Search, Grid3X3, List, Plus, Copy, Type, Image as ImageIcon,
  Film, MoreHorizontal, ChevronDown, X, RefreshCw, Eye, EyeOff,
} from "lucide-react";

type Page = "home" | "conversion" | "gallery";

/* ─────────────────────────────────────────
   Matrix background
───────────────────────────────────────── */
const MATRIX_CHARS =
  "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#$%^&*(){}[]|<>/\\+-=~`";

function MatrixBackground({ visible }: { visible: boolean }) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const resize = () => {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
    };
    resize();
    window.addEventListener("resize", resize);

    const cols = Math.floor(canvas.width / 14);
    const drops: number[] = Array(cols).fill(1);

    const draw = () => {
      if (!visible) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        return;
      }
      ctx.fillStyle = "rgba(10,10,10,0.05)";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      for (let i = 0; i < drops.length; i++) {
        const char = MATRIX_CHARS[Math.floor(Math.random() * MATRIX_CHARS.length)];
        ctx.fillStyle = Math.random() > 0.95 ? "#00ff41" : "#00ff4118";
        ctx.font = "12px 'Share Tech Mono', monospace";
        ctx.fillText(char, i * 14, drops[i] * 14);
        if (drops[i] * 14 > canvas.height && Math.random() > 0.975) drops[i] = 0;
        drops[i]++;
      }
    };

    const interval = setInterval(draw, 60);
    return () => { clearInterval(interval); window.removeEventListener("resize", resize); };
  }, [visible]);

  return (
    <canvas
      ref={ref}
      className="absolute inset-0 w-full h-full pointer-events-none"
      style={{ opacity: visible ? 0.7 : 0, transition: "opacity 0.5s" }}
    />
  );
}

/* ─────────────────────────────────────────
   See History button — rectangular tab
───────────────────────────────────────── */
function SeeHistoryButton({ label, onClick }: { label: string; onClick?: () => void }) {
  const [pressed, setPressed] = useState(false);
  return (
    <button
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
      onMouseLeave={() => setPressed(false)}
      onClick={onClick}
      style={{
        fontFamily: "'Share Tech Mono', monospace",
        fontSize: "11px",
        letterSpacing: "0.08em",
        padding: "7px 18px",
        background: pressed ? "#222" : "#161616",
        color: "#aaa",
        border: "1px solid #333",
        borderBottom: "1px solid #0a0a0a",
        borderRadius: "4px 4px 0 0",
        transform: pressed ? "translateY(1px)" : "translateY(0)",
        transition: "background 0.1s, transform 0.08s",
        cursor: "pointer",
        marginBottom: "-1px",
      }}
    >
      {label}
    </button>
  );
}

/* ─────────────────────────────────────────
   Dark Theme tab — hangs from header
───────────────────────────────────────── */
function DarkThemeButton() {
  const [pressed, setPressed] = useState(false);
  return (
    <button
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
      onMouseLeave={() => setPressed(false)}
      style={{
        fontFamily: "'Share Tech Mono', monospace",
        fontSize: "11px",
        letterSpacing: "0.05em",
        padding: "6px 16px",
        background: pressed ? "#222" : "#161616",
        color: "#666",
        border: "1px solid #2a2a2a",
        borderTop: "none",
        borderRadius: "0 0 6px 6px",
        transform: pressed ? "scale(0.97)" : "scale(1)",
        transition: "background 0.1s, transform 0.08s",
        cursor: "pointer",
      }}
    >
      Dark Theme
    </button>
  );
}

/* ─────────────────────────────────────────
   Generic Dropdown
───────────────────────────────────────── */
function Dropdown({
  value,
  options,
  onChange,
  className = "",
  renderOption,
}: {
  value: string;
  options: string[];
  onChange: (v: string) => void;
  className?: string;
  renderOption?: (opt: string) => React.ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const h = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);

  return (
    <div ref={ref} className={`relative inline-block ${className}`}>
      <button
        onClick={() => setOpen((o) => !o)}
        className="flex items-center gap-1 px-2 py-1.5 border border-[#2a2a2a] bg-[#111] hover:border-[#444] transition-colors duration-150 active:bg-[#1a1a1a]"
        style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: "11px", color: "#c8c8c8", minWidth: "max-content" }}
      >
        {renderOption ? renderOption(value) : value}
        <ChevronDown size={10} className={`ml-1 transition-transform duration-150 ${open ? "rotate-180" : ""}`} />
      </button>
      {open && (
        <div className="absolute top-full left-0 z-50 min-w-full border border-[#333] bg-[#0f0f0f]" style={{ marginTop: "2px" }}>
          {options.map((opt) => (
            <button
              key={opt}
              onClick={() => { onChange(opt); setOpen(false); }}
              className="flex items-center w-full text-left px-3 py-1.5 hover:bg-[#1f1f1f] transition-colors duration-100"
              style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: "11px", color: opt === value ? "#00ff41" : "#c8c8c8" }}
            >
              {renderOption ? renderOption(opt) : opt}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

/* ─────────────────────────────────────────
   Header
───────────────────────────────────────── */
function Header({ page, onNavigate }: { page: Page; onNavigate: (p: Page) => void }) {
  return (
    <header
      className="relative flex items-center justify-between px-5 border-b border-[#1e1e1e] z-30 flex-shrink-0"
      style={{ height: "40px", background: "#0a0a0a" }}
    >
      {/* Dark Theme tab — hangs below header */}
      <div className="absolute left-5 top-full z-40">
        <DarkThemeButton />
      </div>

      {/* Logo + breadcrumb */}
      <div className="flex items-center gap-1" style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: "12px" }}>
        <button
          onClick={() => onNavigate("home")}
          className="hover:opacity-80 transition-opacity font-bold"
          style={{ color: "#e8315e", letterSpacing: "0.05em" }}
        >
          //.VIRGA
        </button>
        <span style={{ color: "#2a2a2a", margin: "0 4px" }}>//</span>
        <button
          onClick={() => onNavigate("conversion")}
          className="hover:text-[#888] transition-colors"
          style={{ color: "#444", letterSpacing: "0.04em" }}
        >
          ASCII PHOTO &amp; VIDEO GENERATOR
        </button>
        {page === "conversion" && (
          <>
            <span style={{ color: "#2a2a2a", margin: "0 4px" }}>/</span>
            <span style={{ color: "#777" }}>CONVERSION</span>
          </>
        )}
        {page === "gallery" && (
          <>
            <span style={{ color: "#2a2a2a", margin: "0 4px" }}>/</span>
            <span style={{ color: "#777" }}>GALLERY</span>
          </>
        )}
      </div>

      {/* Right action */}
      <div>
        {page === "home" && <SeeHistoryButton label="see history" onClick={() => onNavigate("gallery")} />}
        {page === "conversion" && <SeeHistoryButton label="see history" onClick={() => onNavigate("gallery")} />}
        {page === "gallery" && <SeeHistoryButton label="CONVERSION" onClick={() => onNavigate("conversion")} />}
      </div>
    </header>
  );
}

/* ══════════════════════════════════════════
   PAGE 1 — HOME
══════════════════════════════════════════ */
function HomePage({ onNavigate }: { onNavigate: (p: Page) => void }) {
  const [matrixVisible, setMatrixVisible] = useState(true);
  const [matrixBtnPressed, setMatrixBtnPressed] = useState(false);

  return (
    <div className="relative flex-1 overflow-hidden" style={{ background: "#0a0a0a" }}>
      <MatrixBackground visible={matrixVisible} />

      {/* Matrix toggle — top right */}
      <div className="absolute top-3 right-4 z-20">
        <button
          onMouseDown={() => setMatrixBtnPressed(true)}
          onMouseUp={() => setMatrixBtnPressed(false)}
          onMouseLeave={() => setMatrixBtnPressed(false)}
          onClick={() => setMatrixVisible((v) => !v)}
          title={matrixVisible ? "Выключить матрицу" : "Включить матрицу"}
          style={{
            fontFamily: "'Share Tech Mono', monospace",
            fontSize: "10px",
            letterSpacing: "0.05em",
            padding: "5px 12px",
            background: matrixBtnPressed ? "#1a1a1a" : matrixVisible ? "#0d1a0d" : "#111",
            color: matrixVisible ? "#00ff41" : "#444",
            border: `1px solid ${matrixVisible ? "#00ff4144" : "#2a2a2a"}`,
            borderRadius: "4px",
            transform: matrixBtnPressed ? "scale(0.95)" : "scale(1)",
            transition: "all 0.15s",
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            gap: "6px",
          }}
        >
          {matrixVisible ? <Eye size={11} /> : <EyeOff size={11} />}
          MATRIX
        </button>
      </div>

      {/* Crane image — right */}
      <div
        className="absolute right-0 top-0 bottom-0 pointer-events-none"
        style={{ width: "44%", opacity: 0.9 }}
      >
        <ImageWithFallback
          src={craneImage}
          alt="ASCII crane"
          className="w-full h-full object-contain object-right"
        />
      </div>

      {/* Main content */}
      <div
        className="relative z-10 flex flex-col justify-center h-full"
        style={{ paddingLeft: "60px", paddingTop: "70px", maxWidth: "56%" }}
      >
        {/* Tagline */}
        <p
          className="mb-6"
          style={{
            fontFamily: "'Share Tech Mono', monospace",
            fontSize: "16px",
            color: "#00ff41",
            letterSpacing: "0.12em",
          }}
        >
          {"< GENERATE. TRANSFORM. INSPIRE />"}
        </p>

        {/* Virga logo image (replaces ASCII art text) */}
        <div className="mb-7" style={{ maxWidth: "520px" }}>
          <ImageWithFallback
            src={virgaLogo}
            alt="VIRGA ASCII logo"
            className="w-full object-contain object-left"
          />
        </div>

        {/* Heading */}
        <h1
          className="mb-5"
          style={{
            fontFamily: "'Share Tech Mono', monospace",
            fontSize: "28px",
            color: "#c8c8c8",
            letterSpacing: "0.03em",
            lineHeight: "1.25",
            borderLeft: "4px solid #e8315e",
            paddingLeft: "18px",
          }}
        >
          ГЕНЕРАТОР ФОТО И ВИДЕО<br />В ASCII ART
        </h1>

        {/* Description */}
        <p
          className="mb-10"
          style={{
            fontFamily: "'Share Tech Mono', monospace",
            fontSize: "14px",
            color: "#555",
            lineHeight: "1.8",
            maxWidth: "420px",
            paddingLeft: "22px",
          }}
        >
          Преобразуйте изображения и видео в уникальные ASCII-
          произведения. Эстетика символов. Искусство в каждой строке.
        </p>

        {/* CTA buttons */}
        <div className="flex items-center gap-5 mb-10 pl-1">
          <ActionButton label="ПОПРОБОВАТЬ ОНЛАЙН →" variant="primary" onClick={() => onNavigate("conversion")} />
          <ActionButton label="СМОТРЕТЬ ПРИМЕРЫ" variant="secondary" onClick={() => onNavigate("gallery")} />
        </div>

        {/* Social icons */}
        <div className="flex items-center gap-6 pl-1">
          <SocialIcon href="#" title="Telegram">
            <svg viewBox="0 0 24 24" fill="currentColor" style={{ width: "22px", height: "22px" }}>
              <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.562 8.248-1.97 9.289c-.145.658-.537.818-1.084.508l-3-2.21-1.447 1.394c-.16.16-.295.295-.605.295l.213-3.053 5.56-5.023c.242-.213-.054-.333-.373-.12L7.17 14.527l-2.96-.924c-.643-.204-.657-.643.136-.953l11.57-4.461c.537-.194 1.006.131.646.059z" />
            </svg>
          </SocialIcon>
          <SocialIcon href="#" title="GitHub">
            <svg viewBox="0 0 24 24" fill="currentColor" style={{ width: "22px", height: "22px" }}>
              <path d="M12 0C5.374 0 0 5.373 0 12c0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23A11.509 11.509 0 0112 5.803c1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576C20.566 21.797 24 17.3 24 12c0-6.627-5.373-12-12-12z" />
            </svg>
          </SocialIcon>
          <SocialIcon href="#" title="Google">
            <svg viewBox="0 0 24 24" fill="currentColor" style={{ width: "22px", height: "22px" }}>
              <path d="M12.545 10.239v3.821h5.445c-.712 2.315-2.647 3.972-5.445 3.972a6.033 6.033 0 110-12.064c1.498 0 2.866.549 3.921 1.453l2.814-2.814A9.969 9.969 0 0012.545 2C7.021 2 2.543 6.477 2.543 12s4.478 10 10.002 10c8.396 0 10.249-7.85 9.426-11.748l-9.426-.013z" />
            </svg>
          </SocialIcon>
          <SocialIcon href="#" title="Discord">
            <svg viewBox="0 0 24 24" fill="currentColor" style={{ width: "22px", height: "22px" }}>
              <path d="M20.317 4.37a19.791 19.791 0 00-4.885-1.515.074.074 0 00-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 00-5.487 0 12.64 12.64 0 00-.617-1.25.077.077 0 00-.079-.037A19.736 19.736 0 003.677 4.37a.07.07 0 00-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 00.031.057 19.9 19.9 0 005.993 3.03.078.078 0 00.084-.028c.462-.63.874-1.295 1.226-1.994a.076.076 0 00-.041-.106 13.107 13.107 0 01-1.872-.892.077.077 0 01-.008-.128 10.2 10.2 0 00.372-.292.074.074 0 01.077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 01.078.01c.12.098.246.198.373.292a.077.077 0 01-.006.127 12.299 12.299 0 01-1.873.892.077.077 0 00-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 00.084.028 19.839 19.839 0 006.002-3.03.077.077 0 00.032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 00-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z" />
            </svg>
          </SocialIcon>
        </div>
      </div>
    </div>
  );
}

function ActionButton({ label, variant, onClick }: { label: string; variant: "primary" | "secondary"; onClick?: () => void }) {
  const [pressed, setPressed] = useState(false);
  const isPrimary = variant === "primary";
  return (
    <button
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
      onMouseLeave={() => setPressed(false)}
      onClick={onClick}
      style={{
        fontFamily: "'Share Tech Mono', monospace",
        fontSize: "14px",
        letterSpacing: "0.06em",
        padding: "11px 24px",
        border: isPrimary ? "1px solid #00ff41" : "1px solid #2a2a2a",
        background: isPrimary
          ? pressed ? "#00ff4130" : "transparent"
          : pressed ? "#1e1e1e" : "transparent",
        color: isPrimary ? "#00ff41" : "#666",
        transform: pressed ? "scale(0.96)" : "scale(1)",
        transition: "all 0.1s",
        cursor: "pointer",
      }}
    >
      {label}
    </button>
  );
}

function SocialIcon({ href, title, children }: { href: string; title: string; children: React.ReactNode }) {
  return (
    <a
      href={href}
      title={title}
      className="text-[#444] hover:text-[#00ff41] transition-colors duration-200 hover:scale-125 inline-block"
      style={{ transition: "color 0.2s, transform 0.2s" }}
    >
      {children}
    </a>
  );
}

/* ══════════════════════════════════════════
   PAGE 2 — CONVERSION
══════════════════════════════════════════ */

const COLOR_OPTIONS = [
  { label: "COLOR",       hex: null       },
  { label: "GREEN",       hex: "#00ff41"  },
  { label: "RED",         hex: "#ff1744"  },
  { label: "BLUE",        hex: "#40c4ff"  },
  { label: "PURPLE",      hex: "#ce93d8"  },
  { label: "MONOCHROME",  hex: "#c8c8c8"  },
  { label: "CUSTOM",      hex: "#ffd740"  },
];

const SWATCHES = [
  { hex: "#ff1744", label: "RED"    },
  { hex: "#00ff41", label: "GREEN"  },
  { hex: "#40c4ff", label: "BLUE"   },
  { hex: "#ce93d8", label: "PURPLE" },
];

function ConversionPage({ onNavigate }: { onNavigate: (p: Page) => void }) {
  const [fileType, setFileType] = useState("ФОТО");
  const [density, setDensity] = useState(100);
  const [mode, setMode] = useState("MODE");
  const [colorLabel, setColorLabel] = useState("COLOR");
  const [inverted, setInverted] = useState(false);
  const [editingMode, setEditingMode] = useState("PHOTO EDITING");
  const [urlInput, setUrlInput] = useState("");
  const [dragging, setDragging] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [asciiOutput, setAsciiOutput] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [invPressed, setInvPressed] = useState(false);

  const activeColor = COLOR_OPTIONS.find((c) => c.label === colorLabel) ?? COLOR_OPTIONS[0];

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) setUploadedFile(file);
  }, []);

  const handleUpload = () => {
    if (uploadedFile || urlInput) {
      setAsciiOutput(
        `// Processing: ${uploadedFile?.name ?? urlInput}\n\n` +
        "  .:::.   .:::.\n (     ) (     )\n  \`:::'   \`:::'\n\n" +
        "< РЕЗУЛЬТАТ БУДЕТ ОТОБРАЖЁН ЗДЕСЬ />"
      );
    }
  };

  const bumpDensity = (dir: 1 | -1) => {
    setDensity((v) => Math.min(200, Math.max(20, v + dir * 20)));
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden relative" style={{ background: "#0a0a0a" }}>
      <div className="flex flex-1 overflow-hidden" style={{ paddingTop: "36px" }}>
        {/* ── LEFT PANEL ── */}
        <div
          className="flex flex-col overflow-y-auto flex-shrink-0"
          style={{ width: "300px", padding: "24px 20px", borderRight: "1px solid #1e1e1e" }}
        >
          <h1
            style={{
              fontFamily: "'Bebas Neue', sans-serif",
              fontSize: "42px",
              color: "#c8c8c8",
              letterSpacing: "0.06em",
              lineHeight: "1",
              marginBottom: "14px",
            }}
          >
            ЗАГРУЗИТЕ ФАЙЛ
          </h1>

          <p style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: "11px", color: "#555", lineHeight: "1.65", marginBottom: "16px" }}>
            Преобразуйте изображения и видео в<br />
            уникальные ASCII-произведения.<br />
            Эстетика символов. Искусство в каждой строке.
          </p>

          <div className="mb-4">
            <Dropdown value={fileType} options={["ФОТО", "ВИДЕО", "GIF"]} onChange={setFileType} />
          </div>

          {/* Drop zone */}
          <div
            onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
            onDragLeave={() => setDragging(false)}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className="flex flex-col items-center justify-center transition-all duration-200"
            style={{
              border: `1px dashed ${dragging ? "#00ff41" : "#2a2a2a"}`,
              background: dragging ? "#00ff4108" : "#0e0e0e",
              borderRadius: "4px",
              padding: "28px 16px",
              marginBottom: "12px",
              cursor: "pointer",
            }}
          >
            <div style={{ width: "36px", height: "36px", border: "1px solid #333", borderRadius: "4px", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: "12px", color: "#444" }}>
              <Plus size={18} />
            </div>
            <p style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: "11px", color: uploadedFile ? "#00ff41" : "#555", marginBottom: "10px", textAlign: "center" }}>
              {uploadedFile ? uploadedFile.name : "ПЕРЕТАЩИТЕ ФАЙЛ СЮДА"}
            </p>
            {!uploadedFile && (
              <p style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: "10px", color: "#333", marginBottom: "10px" }}>
                или выберите для выбора
              </p>
            )}
            <SmallButton label="ВЫБРАТЬ ФАЙЛ" onClick={(e) => { e.stopPropagation(); fileInputRef.current?.click(); }} />
            <input ref={fileInputRef} type="file" accept="image/*,video/*,.gif" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) setUploadedFile(f); }} />
          </div>

          <div className="flex items-center justify-between mb-4" style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: "9px", color: "#333", borderTop: "1px solid #1a1a1a", paddingTop: "8px" }}>
            <span>JPEG, PNG, GIF, MP4, MOV, WEBM</span>
            <span>МАКС. РАЗМЕР: 150MB</span>
          </div>

          <div className="flex items-center gap-2 mb-4" style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: "10px", color: "#333" }}>
            <div className="flex-1 h-px bg-[#1e1e1e]" />
            <span>или</span>
            <div className="flex-1 h-px bg-[#1e1e1e]" />
          </div>

          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Вставьте ссылку на файл (URL)"
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              className="flex-1 px-2 py-1.5 bg-[#0e0e0e] border border-[#222] focus:border-[#444] focus:outline-none transition-colors"
              style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: "10px", color: "#888" }}
            />
            <SmallButton label="ЗАГРУЗИТЬ" onClick={handleUpload} accent />
          </div>
        </div>

        {/* ── RIGHT PANEL ── */}
        <div className="flex-1 flex flex-col overflow-hidden" style={{ padding: "16px 20px" }}>
          {/* Controls row */}
          <div className="flex items-center gap-2 mb-3 flex-wrap">
            {/* Density stepper */}
            <div className="flex items-center border border-[#2a2a2a] bg-[#111]" style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: "12px" }}>
              <button className="px-2.5 py-1.5 hover:bg-[#1a1a1a] active:bg-[#222] text-[#555] transition-colors" onClick={() => bumpDensity(-1)}>−</button>
              <span className="w-10 text-center text-[#c8c8c8]">{density}</span>
              <button className="px-2.5 py-1.5 hover:bg-[#1a1a1a] active:bg-[#222] text-[#555] transition-colors" onClick={() => bumpDensity(1)}>+</button>
            </div>

            <Dropdown value={mode} options={["MODE", "GRAYSCALE", "BRAILLE", "BLOCKS", "EXTENDED"]} onChange={setMode} />

            {/* INV toggle button */}
            <button
              onMouseDown={() => setInvPressed(true)}
              onMouseUp={() => setInvPressed(false)}
              onMouseLeave={() => setInvPressed(false)}
              onClick={() => setInverted((v) => !v)}
              style={{
                fontFamily: "'Share Tech Mono', monospace",
                fontSize: "11px",
                letterSpacing: "0.06em",
                padding: "6px 14px",
                border: `1px solid ${inverted ? "#00ff41" : "#2a2a2a"}`,
                background: inverted ? "#00ff4120" : invPressed ? "#1a1a1a" : "#111",
                color: inverted ? "#00ff41" : "#888",
                transform: invPressed ? "scale(0.94)" : "scale(1)",
                transition: "all 0.1s",
                cursor: "pointer",
              }}
            >
              INV{inverted ? " ✓" : ""}
            </button>

            {/* Color dropdown with preview */}
            <Dropdown
              value={colorLabel}
              options={COLOR_OPTIONS.map((c) => c.label)}
              onChange={setColorLabel}
              renderOption={(opt) => {
                const c = COLOR_OPTIONS.find((x) => x.label === opt);
                return (
                  <span className="flex items-center gap-2">
                    {c?.hex ? (
                      <span style={{ width: "10px", height: "10px", borderRadius: "2px", background: c.hex, display: "inline-block", border: "1px solid #333", flexShrink: 0 }} />
                    ) : (
                      <span style={{ width: "10px", height: "10px", borderRadius: "2px", background: "linear-gradient(135deg,#ff1744,#00ff41,#40c4ff)", display: "inline-block", border: "1px solid #333", flexShrink: 0 }} />
                    )}
                    {opt}
                  </span>
                );
              }}
            />

            {/* Active color swatches — show which is active */}
            <div className="flex items-center gap-1">
              {SWATCHES.map((s) => {
                const isActive = colorLabel === s.label;
                return (
                  <button
                    key={s.hex}
                    onClick={() => setColorLabel(s.label)}
                    title={s.label}
                    className="transition-all duration-150 hover:scale-110 active:scale-90"
                    style={{
                      width: "18px",
                      height: "18px",
                      background: s.hex,
                      border: isActive ? "2px solid #fff" : "1px solid #333",
                      outline: isActive ? `2px solid ${s.hex}44` : "none",
                      outlineOffset: "2px",
                    }}
                  />
                );
              })}
            </div>

            {/* Current color indicator */}
            {activeColor.hex && (
              <span
                className="flex items-center gap-1.5 px-2 py-1 border border-[#1e1e1e]"
                style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: "10px", color: activeColor.hex }}
              >
                <span style={{ width: "8px", height: "8px", borderRadius: "50%", background: activeColor.hex, display: "inline-block" }} />
                {activeColor.label}
              </span>
            )}

            <div className="flex-1" />
            <button className="text-[#333] hover:text-[#555] transition-colors active:text-[#00ff41]" title="Reset">
              <RefreshCw size={13} />
            </button>
          </div>

          {/* Photo editing row */}
          <div className="flex justify-end mb-3">
            <Dropdown value={editingMode} options={["PHOTO EDITING", "BRIGHTNESS", "CONTRAST", "SHARPEN", "BLUR", "INVERT"]} onChange={setEditingMode} />
          </div>

          {/* Preview area */}
          <div className="flex-1 relative border border-[#1e1e1e] overflow-hidden" style={{ background: "#080808", minHeight: "200px" }}>
            {asciiOutput ? (
              <pre
                className="w-full h-full overflow-auto p-4"
                style={{
                  fontFamily: "'Share Tech Mono', monospace",
                  fontSize: "11px",
                  color: activeColor.hex ?? "#00ff41",
                  lineHeight: "1.3",
                  whiteSpace: "pre",
                  filter: inverted ? "invert(1)" : "none",
                }}
              >
                {asciiOutput}
              </pre>
            ) : (
              <div className="absolute inset-0 flex items-center justify-center">
                <p style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: "13px", color: "#2a2a2a", letterSpacing: "0.05em" }}>
                  ЗДЕСЬ ОТОБРИТСЯ ВАШ ASCII...
                </p>
              </div>
            )}
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2 mt-3 flex-wrap">
            {[
              { label: "КОПИЯ",   icon: <Copy size={11} />,        action: () => { if (asciiOutput) navigator.clipboard.writeText(asciiOutput); } },
              { label: "ТЕКСТ",   icon: <Type size={11} /> },
              { label: "PNG",     icon: <ImageIcon size={11} /> },
              { label: "GIF",     icon: <Film size={11} /> },
              { label: "ВИДЕО",   icon: <Film size={11} /> },
              { label: "ПРОЧЕЕ",  icon: <MoreHorizontal size={11} /> },
              { label: "ГАЛЕРЕЯ", icon: <Grid3X3 size={11} />,     action: () => onNavigate("gallery") },
            ].map(({ label, icon, action }) => (
              <BottomActionButton key={label} label={label} icon={icon} onClick={action} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function SmallButton({ label, onClick, accent = false }: { label: string; onClick?: (e: React.MouseEvent) => void; accent?: boolean }) {
  const [pressed, setPressed] = useState(false);
  return (
    <button
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
      onMouseLeave={() => setPressed(false)}
      onClick={onClick}
      style={{
        fontFamily: "'Share Tech Mono', monospace",
        fontSize: "10px",
        letterSpacing: "0.06em",
        padding: "5px 12px",
        border: `1px solid ${accent ? "#444" : "#333"}`,
        background: pressed ? "#222" : "#111",
        color: accent ? "#c8c8c8" : "#888",
        transform: pressed ? "scale(0.95)" : "scale(1)",
        transition: "all 0.1s",
        cursor: "pointer",
      }}
    >
      {label}
    </button>
  );
}

function BottomActionButton({ label, icon, onClick }: { label: string; icon: React.ReactNode; onClick?: () => void }) {
  const [pressed, setPressed] = useState(false);
  return (
    <button
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
      onMouseLeave={() => setPressed(false)}
      onClick={onClick}
      className="flex items-center gap-1.5 hover:border-[#444] hover:text-[#c8c8c8] transition-all duration-100"
      style={{
        fontFamily: "'Share Tech Mono', monospace",
        fontSize: "10px",
        letterSpacing: "0.06em",
        padding: "6px 14px",
        border: "1px solid #222",
        background: pressed ? "#1a1a1a" : "#0d0d0d",
        color: "#666",
        transform: pressed ? "scale(0.94)" : "scale(1)",
        cursor: "pointer",
      }}
    >
      {icon}
      {label}
    </button>
  );
}

/* ══════════════════════════════════════════
   PAGE 3 — GALLERY
══════════════════════════════════════════ */
const GALLERY_ITEMS = [
  { id: 1,  name: "tree.ascii",         ext: "png", w: 120, h: 120, time: "1 min ago"   },
  { id: 2,  name: "hello_kitty.ascii",  ext: "png", w: 80,  h: 90,  time: "5 min ago"   },
  { id: 3,  name: "da12.ascii",         ext: "png", w: 120, h: 100, time: "42 min ago"  },
  { id: 4,  name: "Drowning_Bat.ascii", ext: "png", w: 120, h: 120, time: "54 min ago"  },
  { id: 5,  name: "nast10cd.ascii",     ext: "png", w: 120, h: 120, time: "39 min ago"  },
  { id: 6,  name: "goatman.ascii",      ext: "png", w: 160, h: 140, time: "1 hour ago"  },
  { id: 7,  name: "timon.ascii",        ext: "png", w: 120, h: 160, time: "2 hour ago"  },
  { id: 8,  name: "wire.ascii",         ext: "png", w: 80,  h: 60,  time: "2 hour ago"  },
  { id: 9,  name: "wave.ascii",         ext: "png", w: 120, h: 120, time: "2 hour ago"  },
  { id: 10, name: "skull.ascii",        ext: "png", w: 80,  h: 80,  time: "23 days ago" },
];

const GALLERY_COLOR_SWATCHES = ["#e53935","#ff9800","#ffeb3b","#00e676","#40c4ff","#9c27b0","#ec407a"];

function GalleryPage({ onNavigate }: { onNavigate: (p: Page) => void }) {
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [filterType, setFilterType] = useState("ALL");
  const [sortBy, setSortBy] = useState("DATE (NEWEST)");
  const [search, setSearch] = useState("");
  const [activeColor, setActiveColor] = useState<string | null>(null);

  const filtered = GALLERY_ITEMS.filter((item) => {
    const ms = item.name.toLowerCase().includes(search.toLowerCase());
    const mt = filterType === "ALL" || (filterType === "IMAGE" && item.ext === "png") || (filterType === "GIF" && item.ext === "gif") || (filterType === "VIDEO" && item.ext === "mp4");
    return ms && mt;
  });

  return (
    <div className="flex-1 flex overflow-hidden relative" style={{ background: "#0a0a0a" }}>
      {/* ── LEFT SIDEBAR ── */}
      <div
        className="flex flex-col overflow-y-auto flex-shrink-0"
        style={{ width: "175px", padding: "44px 14px 14px", borderRight: "1px solid #1e1e1e" }}
      >
        <GSection title="GALLERY_STATS">
          {[["TOTAL FILES","10"],["IMAGES","8"],["VIDEOS","1"],["GIFS","1"],["STORAGE USED","2.4 MB"]].map(([k,v]) => (
            <div key={k} className="flex justify-between items-center mb-1">
              <span style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: "9px", color: "#444" }}>{k}</span>
              <span style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: "9px", color: "#666" }}>{v}</span>
            </div>
          ))}
        </GSection>

        <DottedDivider />

        <GSection title="FILTERS">
          <p style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: "9px", color: "#444", marginBottom: "6px" }}>TYPE</p>
          {["ALL","IMAGE","GIF","VIDEO"].map((t) => (
            <label key={t} className="flex items-center gap-1.5 mb-1.5 cursor-pointer">
              <div
                onClick={() => setFilterType(t)}
                className="w-3 h-3 border flex items-center justify-center flex-shrink-0 transition-colors"
                style={{ borderColor: filterType === t ? "#00ff41" : "#333", background: filterType === t ? "#00ff4122" : "transparent", borderRadius: "50%" }}
              >
                {filterType === t && <div className="w-1.5 h-1.5 rounded-full bg-[#00ff41]" />}
              </div>
              <span style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: "9px", color: filterType === t ? "#00ff41" : "#555" }}>{t}</span>
            </label>
          ))}

          <p style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: "9px", color: "#444", margin: "8px 0 6px" }}>COLOR</p>
          <div className="flex flex-wrap gap-1 mb-3">
            {GALLERY_COLOR_SWATCHES.map((c) => (
              <button
                key={c}
                onClick={() => setActiveColor(activeColor === c ? null : c)}
                className="w-4 h-4 transition-all hover:scale-110 active:scale-95"
                style={{ background: c, border: activeColor === c ? "1px solid #fff" : "1px solid transparent" }}
              />
            ))}
          </div>

          <p style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: "9px", color: "#444", marginBottom: "6px" }}>SORT BY</p>
          <Dropdown
            value={sortBy}
            options={["DATE (NEWEST)","DATE (OLDEST)","NAME (A-Z)","NAME (Z-A)","SIZE"]}
            onChange={setSortBy}
            className="w-full mb-3"
          />

          <button
            onClick={() => { setFilterType("ALL"); setActiveColor(null); setSortBy("DATE (NEWEST)"); }}
            className="w-full text-center py-1 hover:border-[#555] hover:text-[#888] transition-colors active:bg-[#1a1a1a]"
            style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: "9px", color: "#444", border: "1px solid #222", letterSpacing: "0.05em", marginBottom: "10px" }}
          >
            CLEAR FILTERS
          </button>
        </GSection>

        <DottedDivider />

        <button
          className="text-left hover:opacity-80 transition-opacity active:opacity-60"
          style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: "10px", color: "#00ff41", letterSpacing: "0.05em" }}
        >
          {">"} LOAD MORE
        </button>
      </div>

      {/* ── MAIN GALLERY ── */}
      <div className="flex-1 flex flex-col overflow-hidden" style={{ padding: "44px 16px 16px" }}>
        {/* Top bar */}
        <div className="flex items-center gap-3 mb-4 flex-shrink-0">
          <div className="flex items-center gap-2 flex-1 border border-[#1e1e1e] bg-[#0d0d0d] px-3 py-1.5 hover:border-[#333] transition-colors focus-within:border-[#444]">
            <Search size={12} className="text-[#333] flex-shrink-0" />
            <input
              type="text"
              placeholder="SEARCH GALLERY..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="flex-1 bg-transparent focus:outline-none"
              style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: "11px", color: "#888" }}
            />
            {search && <button onClick={() => setSearch("")} className="text-[#333] hover:text-[#666]"><X size={11} /></button>}
          </div>

          <div className="flex border border-[#1e1e1e]">
            {(["grid","list"] as const).map((v) => (
              <button
                key={v}
                onClick={() => setViewMode(v)}
                className="px-2.5 py-1.5 transition-colors active:bg-[#222]"
                style={{ background: viewMode === v ? "#1a1a1a" : "transparent", color: viewMode === v ? "#00ff41" : "#444", borderRight: v === "grid" ? "1px solid #1e1e1e" : "none" }}
              >
                {v === "grid" ? <Grid3X3 size={13} /> : <List size={13} />}
              </button>
            ))}
          </div>

          <button
            onClick={() => onNavigate("conversion")}
            className="flex items-center gap-1.5 px-3 py-1.5 border border-[#00ff41] text-[#00ff41] hover:bg-[#00ff4111] active:bg-[#00ff4122] transition-colors flex-shrink-0"
            style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: "10px", letterSpacing: "0.05em" }}
          >
            <Plus size={11} />
            NEW CONVERSION
          </button>
        </div>

        {/* Gallery grid — paddingTop ensures hover lift doesn't clip */}
        {viewMode === "grid" ? (
          <div
            className="flex-1 overflow-y-auto"
            style={{ paddingTop: "6px" }}
          >
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fill, minmax(155px, 1fr))",
                gap: "10px",
                alignContent: "start",
              }}
            >
              {filtered.map((item) => (
                <GalleryCard key={item.id} item={item} />
              ))}
            </div>
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto">
            <table className="w-full" style={{ borderCollapse: "collapse" }}>
              <thead>
                <tr style={{ borderBottom: "1px solid #1e1e1e" }}>
                  {["NAME","SIZE","TYPE","UPLOADED"].map((col) => (
                    <th key={col} className="text-left pb-2" style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: "9px", color: "#444", letterSpacing: "0.05em", padding: "0 8px 8px 0" }}>{col}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((item) => (
                  <tr key={item.id} className="hover:bg-[#0e0e0e] transition-colors" style={{ borderBottom: "1px solid #111" }}>
                    <td className="py-2 pr-8" style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: "10px", color: "#888" }}>{item.name}</td>
                    <td style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: "10px", color: "#444" }}>{item.w}x{item.h}</td>
                    <td style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: "10px", color: "#444" }}>{item.ext}</td>
                    <td style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: "10px", color: "#444" }}>{item.time}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

function GalleryCard({ item }: { item: (typeof GALLERY_ITEMS)[0] }) {
  const [hovered, setHovered] = useState(false);
  return (
    <div
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className="cursor-pointer"
      style={{
        border: `1px solid ${hovered ? "#3a3a3a" : "#1e1e1e"}`,
        background: "#0d0d0d",
        transform: hovered ? "translateY(-3px)" : "translateY(0)",
        transition: "transform 0.2s, border-color 0.2s, box-shadow 0.2s",
        boxShadow: hovered ? "0 6px 20px rgba(0,0,0,0.6)" : "none",
      }}
    >
      {/* ╔══════════════════════════════════════════╗
          ║  IMAGE PLACEHOLDER — item #{item.id}     ║
          ║  Замените этот блок на:                  ║
          ║                                          ║
          ║  import img{item.id} from "@/imports/…"  ║
          ║                                          ║
          ║  <ImageWithFallback                      ║
          ║    src={img{item.id}}                    ║
          ║    alt="{item.name}"                     ║
          ║    className="w-full h-full object-cover"║
          ║  />                                      ║
          ╚══════════════════════════════════════════╝ */}
      <div style={{ height: "120px", background: "#111", borderBottom: "1px solid #1a1a1a", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <span style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: "9px", color: "#222", textAlign: "center", lineHeight: "1.5" }}>
          IMAGE<br />PLACEHOLDER<br />#{item.id}
        </span>
      </div>

      <div className="p-2">
        <p className="truncate mb-0.5" style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: "9px", color: hovered ? "#00ff41" : "#666", transition: "color 0.15s" }}>
          {item.name}
        </p>
        <p style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: "8px", color: "#333" }}>
          {item.ext} {item.w}x{item.h}
        </p>
        <p style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: "8px", color: "#2a2a2a" }}>
          {item.time}
        </p>
      </div>
    </div>
  );
}

function GSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mb-3">
      <p className="mb-2" style={{ fontFamily: "'Share Tech Mono', monospace", fontSize: "9px", color: "#00ff41", letterSpacing: "0.08em" }}>{title}</p>
      {children}
    </div>
  );
}

function DottedDivider() {
  return <div className="my-3" style={{ borderTop: "1px dashed #1e1e1e" }} />;
}

/* ══════════════════════════════════════════
   ROOT APP
══════════════════════════════════════════ */
export default function App() {
  const [page, setPage] = useState<Page>("home");

  return (
    <div className="flex flex-col" style={{ height: "100vh", overflow: "hidden", background: "#0a0a0a" }}>
      <Header page={page} onNavigate={setPage} />
      {page === "home" && <HomePage onNavigate={setPage} />}
      {page === "conversion" && <ConversionPage onNavigate={setPage} />}
      {page === "gallery" && <GalleryPage onNavigate={setPage} />}
    </div>
  );
}
